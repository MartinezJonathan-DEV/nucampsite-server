## 1.5.1

 - perf: minor performance tweak when growing queue size (#29)

## 1.5.0

 - feat: adds capacity option for circular buffers (#27)

