
var css = require('./')
  , assert = require('assert');

assert(css.parse);
assert(css.stringify);
